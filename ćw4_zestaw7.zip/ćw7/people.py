
from datetime import date


class Person:
    people_count = 0

    def __init__(self, first_name, last_name, email):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        Person.people_count += 1

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def introduce(self):
        return f"My name is {self.full_name}"

    def __str__(self):
        return self.full_name

    def __eq__(self, other):
        return self.email == other.email


class Employee(Person):

    def __init__(self, first_name, last_name, email,
                 employee_id, salary):
        super().__init__(first_name, last_name, email)
        self.employee_id = employee_id
        self.__salary = salary
        self.active = True

    def get_salary(self):
        return self.__salary

    def set_salary(self, new_salary):
        self.__salary = new_salary

    def deactivate(self):
        self.active = False

    def introduce(self):
        return (
            super().introduce()
            + f". Employee ID: {self.employee_id}"
        )


class Researcher(Employee):

    def __init__(self, first_name, last_name, email,
                 employee_id, salary, specialization):
        super().__init__(
            first_name, last_name, email,
            employee_id, salary
        )
        self.specialization = specialization
        self.projects = []

    def add_project(self, project):
        self.projects.append(project)

    def introduce(self):
        return (
            super().introduce()
            + f". Specialization: {self.specialization}"
        )


class LabTechnician(Employee):

    def __init__(self, first_name, last_name, email,
                 employee_id, salary, shift):
        super().__init__(
            first_name, last_name, email,
            employee_id, salary
        )
        self.shift = shift

    def introduce(self):
        return (
            super().introduce()
            + f". Shift: {self.shift}"
        )


class Administrator(Employee):

    def __init__(self, first_name, last_name, email,
                 employee_id, salary, access_level):
        super().__init__(
            first_name, last_name, email,
            employee_id, salary
        )
        self.access_level = access_level

    @staticmethod
    def validate_email(email):
        return "@" in email and "." in email

    @classmethod
    def create_guest(cls, number):
        return cls(
            "Guest", str(number),
            f"guest{number}@biolab.com",
            f"G{number}", 0, "guest"
        )

    def introduce(self):
        return super().introduce() + ". Administrator"
