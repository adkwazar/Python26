
from datetime import datetime


class Analysis:
    analysis_count = 0

    def __init__(self, name, researcher, equipment=None):
        self.name = name
        self.researcher = researcher
        self.equipment = equipment
        self.created_at = datetime.now()
        self._results = []

        Analysis.analysis_count += 1

    def perform(self, sample):
        raise NotImplementedError(
            "This method should be implemented in subclasses"
        )

    def add_result(self, result):
        self._results.append(result)

    @property
    def results(self):
        return self._results

    @classmethod
    def get_analysis_count(cls):
        return cls.analysis_count

    @staticmethod
    def calculate_average(values):
        if len(values) == 0:
            return 0
        return sum(values) / len(values)

    def __str__(self):
        return f"Analysis: {self.name}"


class MicroscopicAnalysis(Analysis):

    def perform(self, sample):
        print("Using microscope:", self.equipment)
        result = f"Microscopic examination of {sample.sample_id}"
        self.add_result(result)
        return result


class GeneticAnalysis(Analysis):

    def perform(self, sample):
        print("Performing genetic analysis")
        result = f"DNA examination of {sample.sample_id}"
        self.add_result(result)
        return result


class ChemicalAnalysis(Analysis):

    def perform(self, sample):
        print("Performing chemical analysis")
        result = f"Chemical examination of {sample.sample_id}"
        self.add_result(result)
        return result


class ResearchProject:

    def __init__(self, project_name, leader, budget):
        self.project_name = project_name
        self.leader = leader
        self.budget = budget
        self.members = []
        self.analyses = []
        self.active = True

    def add_member(self, employee):
        self.members.append(employee)

    def add_analysis(self, analysis):
        self.analyses.append(analysis)

    def close_project(self):
        self.active = False

    def add_funds(self, amount):
        self.budget += amount

    def __str__(self):
        return f"Project: {self.project_name}"
