
from datetime import date

from people import Researcher, LabTechnician, Administrator
from samples import (
    BloodSample, TissueSample, WaterSample,
    DNA_Sample, SampleContainer
)
from equipment import Microscope, Centrifuge, Freezer
from research import (
    ResearchProject, MicroscopicAnalysis,
    GeneticAnalysis, ChemicalAnalysis
)
from laboratory import Laboratory
from reports import Report


# CREATE LABORATORIES

lab1 = Laboratory("BioLab", "Krakow")
lab2 = Laboratory("GenLab", "Warsaw")


# CREATE EMPLOYEES

researcher1 = Researcher(
    "Anna", "Nowak", "anna@biolab.pl",
    "R001", 7500, "Genetics"
)

technician1 = LabTechnician(
    "Piotr", "Kowalski", "piotr@biolab.pl",
    "T001", 5200, "Morning"
)

admin1 = Administrator(
    "Maria", "Wisniewska", "maria@biolab.pl",
    "A001", 6800, "Full"
)


# CREATE SAMPLES

sample1 = BloodSample(
    "S0001", date(2026, 10, 10),
    researcher1, "A+"
)

sample2 = TissueSample(
    "S0002", date(2026, 10, 11),
    researcher1, "Liver"
)

sample3 = WaterSample(
    "S0003", date(2026, 10, 12),
    technician1, "Vistula", 7.2
)

sample4 = DNA_Sample(
    "S0004", date(2026, 10, 13),
    researcher1, "ATCGGCTA"
)


# ADD SAMPLES TO LABORATORIES

lab1.add_sample(sample1)
lab1.add_sample(sample2)
lab1.add_sample(sample3)

lab2.add_sample(sample4)


# ADD EMPLOYEES

lab1.add_employee(researcher1)
lab1.add_employee(technician1)
lab1.add_employee(admin1)


# CREATE EQUIPMENT

microscope = Microscope(
    "Olympus CX23", "M001", "good", 1000
)

centrifuge = Centrifuge(
    "Eppendorf 5810", "C001", "good", 14000
)

freezer = Freezer(
    "UltraFreezer", "F001", "good", -80
)

lab1.add_equipment(microscope)
lab1.add_equipment(centrifuge)
lab1.add_equipment(freezer)


# CREATE RESEARCH PROJECT

project = ResearchProject(
    "Genome Research", researcher1, 50000
)

project.add_member(technician1)
project.add_member(admin1)

researcher1.add_project(project)
lab1.add_project(project)


# CREATE ANALYSES

analysis1 = GeneticAnalysis(
    "DNA sequencing", researcher1, microscope
)

analysis2 = MicroscopicAnalysis(
    "Tissue examination", researcher1, microscope
)

analysis3 = ChemicalAnalysis(
    "Water chemistry", researcher1, None
)

project.add_analysis(analysis1)
project.add_analysis(analysis2)
project.add_analysis(analysis3)


# RUN SYSTEM

print("=== LABORATORY ===")
print(lab1)

print("\n=== EMPLOYEES ===")
lab1.show_employees()

print("\n=== SAMPLES ===")
lab1.analyze_all()

print("\n=== RESEARCH ANALYSES ===")
print(analysis1.perform(sample4))
print(analysis2.perform(sample2))
print(analysis3.perform(sample3))

print("\n=== EQUIPMENT ===")
lab1.show_equipment()

print("\n=== REPORT ===")
report = Report("Monthly Report", lab1, researcher1)
report.generate()
report.display()

print("\n=== STATISTICS ===")
print("People:", researcher1.people_count)
print("Samples:", sample1.total_samples)
print("Reports:", Report.get_report_count())
print("Laboratories:", Laboratory.get_laboratory_count())

print("\n=== STATIC METHODS ===")
print(
    "Valid email:",
    Administrator.validate_email("test@biolab.pl")
)

print("\n=== GUEST ===")
guest = Administrator.create_guest(1)
print(guest.introduce())
