
class Equipment:

    equipment_count = 0

    def __init__(self, name, serial_number, condition):
        self.name = name
        self.serial_number = serial_number
        self.condition = condition
        self.in_use = False
        Equipment.equipment_count += 1

    def use(self):
        if self.condition == "damaged":
            print("Equipment is damaged!")
            return False

        self.in_use = True
        print(f"{self.name} is now in use")
        return True

    def release(self):
        self.in_use = False

    def get_info(self):
        return f"{self.name}: {self.condition}"

    @classmethod
    def get_equipment_count(cls):
        return cls.equipment_count

    def __str__(self):
        return self.get_info()


class Microscope(Equipment):

    def __init__(self, name, serial_number, condition,
                 magnification):
        super().__init__(name, serial_number, condition)
        self.magnification = magnification

    def get_info(self):
        return (
            super().get_info()
            + f", magnification: {self.magnification}x"
        )


class Centrifuge(Equipment):

    def __init__(self, name, serial_number, condition,
                 max_rpm):
        super().__init__(name, serial_number, condition)
        self.max_rpm = max_rpm

    def get_info(self):
        return super().get_info() + f", max RPM: {self.max_rpm}"


class Freezer(Equipment):

    def __init__(self, name, serial_number, condition,
                 temperature):
        super().__init__(name, serial_number, condition)
        self.temperature = temperature

    def get_info(self):
        return (
            super().get_info()
            + f", temperature: {self.temperature} C"
        )
