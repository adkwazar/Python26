
class Report:

    report_count = 0

    def __init__(self, title, laboratory, author):
        self.title = title
        self.laboratory = laboratory
        self.author = author
        self.generated = False
        self.content = ""

        Report.report_count += 1

    def generate(self):
        lines = [
            f"REPORT: {self.title}",
            f"Laboratory: {self.laboratory.name}",
            f"Author: {self.author.full_name}",
            "-----------------------------"
        ]

        for sample in self.laboratory.samples:
            lines.append(
                f"{sample.sample_id}: {sample.result}"
            )

        self.content = "\n".join(lines)
        self.generated = True

    def display(self):
        if not self.generated:
            print("Report has not been generated")
        else:
            print(self.content)

    @classmethod
    def get_report_count(cls):
        return cls.report_count

    @staticmethod
    def format_date(date_value):
        return date_value.strftime("%Y-%m-%d")

    def __str__(self):
        return f"Report: {self.title}"
