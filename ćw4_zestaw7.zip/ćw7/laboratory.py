
from samples import BloodSample, TissueSample, WaterSample
from samples import DNA_Sample, SampleContainer


class Laboratory:

    laboratory_count = 0

    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.samples = SampleContainer()
        self.employees = []
        self.equipment = []
        self.projects = []

        Laboratory.laboratory_count += 1

    def add_sample(self, sample):
        self.samples.add(sample)

    def add_employee(self, employee):
        self.employees.append(employee)

    def add_equipment(self, equipment):
        self.equipment.append(equipment)

    def add_project(self, project):
        self.projects.append(project)

    def analyze_all(self):
        for sample in self.samples:

            if isinstance(sample, BloodSample):
                sample.analyze()

            elif isinstance(sample, TissueSample):
                sample.analyze()

            elif isinstance(sample, WaterSample):
                sample.analyze()

            elif isinstance(sample, DNA_Sample):
                sample.analyze()

            else:
                print("Unknown sample type")

    def show_employees(self):
        for employee in self.employees:
            print(employee.introduce())

    def show_equipment(self):
        for equipment in self.equipment:
            print(equipment.get_info())

    def find_sample(self, sample_id):
        for sample in self.samples:
            if sample.sample_id == sample_id:
                return sample
        return None

    @classmethod
    def get_laboratory_count(cls):
        return cls.laboratory_count

    def __str__(self):
        return (
            f"{self.name}, {self.address}, "
            f"{len(self.samples)} samples"
        )
