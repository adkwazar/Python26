
from datetime import datetime


class Sample:
    total_samples = 0

    def __init__(self, sample_id, collection_date,
                 collected_by):
        self.sample_id = sample_id
        self.collection_date = collection_date
        self.collected_by = collected_by
        self._result = None
        self.__status = "registered"

        Sample.total_samples += 1

    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value

    @property
    def status(self):
        return self.__status

    def change_status(self, new_status):
        self.__status = new_status

    def analyze(self):
        print("General sample analysis")
        self.result = "General result"
        self.change_status("analyzed")

    def get_description(self):
        return f"Sample {self.sample_id}"

    @classmethod
    def from_dict(cls, data):
        return cls(
            data["sample_id"],
            data["collection_date"],
            data["collected_by"]
        )

    @staticmethod
    def validate_sample_id(sample_id):
        return (
            isinstance(sample_id, str)
            and sample_id.startswith("S")
            and len(sample_id) == 5
        )

    def __str__(self):
        return f"{self.sample_id} ({self.status})"

    def __repr__(self):
        return f"Sample('{self.sample_id}')"


class BloodSample(Sample):

    def __init__(self, sample_id, collection_date,
                 collected_by, blood_group):
        super().__init__(
            sample_id, collection_date, collected_by
        )
        self.blood_group = blood_group
        self.red_cell_count = 0

    def analyze(self):
        print("Performing blood analysis...")
        self.red_cell_count = 4.8
        self.result = f"Blood group: {self.blood_group}"
        self.change_status("analyzed")

    def get_description(self):
        return (
            super().get_description()
            + f", group {self.blood_group}"
        )


class TissueSample(Sample):

    def __init__(self, sample_id, collection_date,
                 collected_by, tissue_type):
        super().__init__(
            sample_id, collection_date, collected_by
        )
        self.tissue_type = tissue_type

    def analyze(self):
        print("Performing tissue analysis...")
        self.result = f"Tissue type: {self.tissue_type}"
        self.change_status("analyzed")


class WaterSample(Sample):

    def __init__(self, sample_id, collection_date,
                 collected_by, location, ph):
        super().__init__(
            sample_id, collection_date, collected_by
        )
        self.location = location
        self.ph = ph

    def analyze(self):
        print("Performing water analysis...")

        if self.ph < 6.5:
            self.result = "Water is acidic"
        elif self.ph > 8.5:
            self.result = "Water is alkaline"
        else:
            self.result = "Water pH is within the selected range"

        self.change_status("analyzed")


class DNA_Sample(Sample):

    def __init__(self, sample_id, collection_date,
                 collected_by, sequence):
        super().__init__(
            sample_id, collection_date, collected_by
        )
        self.sequence = sequence

    def analyze(self):
        print("Performing DNA analysis...")
        self.result = f"Sequence length: {len(self.sequence)}"
        self.change_status("analyzed")


class SampleContainer:

    def __init__(self, samples=[]):
        self.samples = samples

    def add(self, sample):
        self.samples.append(sample)

    def remove(self, sample_id):
        self.samples = [
            s for s in self.samples
            if s.sample_id != sample_id
        ]

    def __len__(self):
        return len(self.samples)

    def __iter__(self):
        return iter(self.samples)

    def __getitem__(self, index):
        return self.samples[index]
